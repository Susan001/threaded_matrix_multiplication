time -p ./matrix
